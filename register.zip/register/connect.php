<?php

$connect=mysqli_connect('localhost','root','','HALIMA');
$fName=$_POST['fName'];
$lName=$_POST['lName'];
$email=$_POST['email'];

$insert= mysqli_query($connect,"INSERT INTO form(fName,lName,email) VALUES('$fName','$lName','$email')");
if ($insert==true) {
	
	echo "data submited in a database";
}
else{

	echo "connection failed";
}



?>